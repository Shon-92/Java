/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trycatchauto;

/**
 *
 * @author 2167784
 */
public class Lot {

    /**
     * @return the spots
     */
    public ParkingSpot getSpots() {
        return spots;
    }

    /**
     * @param spots the spots to set
     */
    public void setSpots(ParkingSpot spots) {
        this.spots = spots;
    }
    private ParkingSpot spots;
}
