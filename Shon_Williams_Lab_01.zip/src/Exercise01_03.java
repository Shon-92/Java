public class Exercise01_03 {
	// Print my intials SMW in a cool way 
	public static void main(String [] args) {
		    System.out.println(" S S S   MM            MM  W          W");
		    System.out.println("S        M M          M M  W          W");
		    System.out.println("S S      M  M        M  M  W    WW    W");
		    System.out.println("  S S    M   M      M   M  W   W  W   W");
		    System.out.println("      S  M    M    M    M  W  W    W  W");
		    System.out.println("      S  M     M  M     M  W W      W W");
		    System.out.println("S S S    M      MM      M  WW        WW");
	 }

}
