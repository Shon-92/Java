
public class Exercise01_01 {
	public static void main(String[] args) {
		// Print welcome to java, my high school and programming is my future
		System.out.println("Welcome to Java.");
		System.out.println("The high school I attended is Douglas Byrd High School.");
		System.out.println("Programming is my future (maybe). ");

	}

}
